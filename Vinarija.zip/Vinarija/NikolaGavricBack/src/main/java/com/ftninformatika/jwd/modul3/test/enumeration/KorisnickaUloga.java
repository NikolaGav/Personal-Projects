package com.ftninformatika.jwd.modul3.test.enumeration;

public enum KorisnickaUloga {
    ADMIN,
    KORISNIK
}
