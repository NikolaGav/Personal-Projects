package com.ftninformatika.jwd.modul3.test.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class TipVina {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String ime;
	
	@OneToMany(mappedBy = "tipVina")
	private List<Vino> vino;

	public TipVina() {
		super();
	}

	public TipVina(Long id, String ime, List<Vino> vino) {
		super();
		this.id = id;
		this.ime = ime;
		this.vino = vino;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public List<Vino> getVino() {
		return vino;
	}

	public void setVino(List<Vino> vino) {
		this.vino = vino;
	}
	
	
	
	

}
