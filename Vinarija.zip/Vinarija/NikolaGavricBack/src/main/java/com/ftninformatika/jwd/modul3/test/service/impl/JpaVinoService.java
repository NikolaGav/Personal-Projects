package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.Vino;
import com.ftninformatika.jwd.modul3.test.repository.VinoRepository;
import com.ftninformatika.jwd.modul3.test.service.VinoService;

@Service
public class JpaVinoService implements VinoService {
	
	@Autowired
	private VinoRepository vinoRepository;

	@Override
	public Vino findOne(Long id) {

		Optional<Vino> vino = vinoRepository.findById(id);
		if(vino.isPresent()) {
			return vino.get();
		}
		
		return null;
	}

	@Override
	public Vino save(Vino vino) {
		return vinoRepository.save(vino);
	}

	@Override
	public void delete(Vino vino) {
		vinoRepository.delete(vino);
		
	}
	

	@Override
	public Page<Vino> findSearch(Long vinarijaId, String imeVina, Integer pageNo) {
		
		if(imeVina == null) {
			return vinoRepository.findByImeIgnoreCaseContains(imeVina, PageRequest.of(pageNo, 3));
		}
		
		return vinoRepository.findByImeIgnoreCaseContainsAndVinarijaId(imeVina, vinarijaId, PageRequest.of(pageNo, 3));
	}

	
	
	
	

}
