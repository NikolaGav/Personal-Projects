package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;

import com.ftninformatika.jwd.modul3.test.model.User;

public interface UserService {
	
	
	 Optional<User> findOne(Long id);

	    List<User> findAll();

	    Page<User> findAll(int pageNo);

	    User save(User user);

	    void delete(Long id);

	    Optional<User> findByUsername(String username);

	
	

}
