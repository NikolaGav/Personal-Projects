package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.WineType;
import com.ftninformatika.jwd.modul3.test.repository.WineTypeRepository;

@Service
public class JpaWineTypeService implements WineTypeService {
	
	
	@Autowired
	private WineTypeRepository wineTypeRepository;
	

	@Override
	public List<WineType> findAll() {
		return wineTypeRepository.findAll();
	}

	@Override
	public WineType findOneById(Long id) {
		return wineTypeRepository.findOneById(id);
	}

}
