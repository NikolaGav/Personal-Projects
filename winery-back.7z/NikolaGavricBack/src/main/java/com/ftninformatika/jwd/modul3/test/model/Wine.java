package com.ftninformatika.jwd.modul3.test.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;

@Entity
public class Wine {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	
	@Column(nullable = false)
	@NotBlank
	private String name;
	
	@Column
	private String description;
	
	@Column(nullable = false)
	private Integer year;
	
	@Column
	private Double bottlePrice;
	
	@Column
	private Integer availableBottles;
	
	@ManyToOne
	private WineType wineType;
	
	@ManyToOne
	private Winery winery;

	public Wine() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Double getBottlePrice() {
		return bottlePrice;
	}

	public void setBottlePrice(Double bottlePrice) {
		this.bottlePrice = bottlePrice;
	}

	public Integer getAvailableBottles() {
		return availableBottles;
	}

	public void setAvailableBottles(Integer availableBottles) {
		this.availableBottles = availableBottles;
	}

	public WineType getWineType() {
		return wineType;
	}

	public void setWineType(WineType wineType) {
		this.wineType = wineType;
	}

	public Winery getWinery() {
		return winery;
	}

	public void setWinery(Winery winery) {
		this.winery = winery;
	}
	
	
	
	
	

}
