package com.ftninformatika.jwd.modul3.test.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Wine;
import com.ftninformatika.jwd.modul3.test.service.impl.WineService;
import com.ftninformatika.jwd.modul3.test.service.impl.WineTypeService;
import com.ftninformatika.jwd.modul3.test.service.impl.WineryService;
import com.ftninformatika.jwd.modul3.test.web.dto.WineDTO;

@Component
public class WineDtoToWine implements Converter<WineDTO, Wine> {
	
	@Autowired
	private WineService wineService;

	@Autowired
	private WineryService wineryService;
	
	@Autowired
	private WineTypeService wineTypeService;
	
	@Override
	public Wine convert(WineDTO source) {
		
		Wine wine;
		
		if(source.getId() == null) {
			wine = new Wine();
		} else {
			wine = wineService.findOneById(source.getId());
		}
		
		wine.setName(source.getName());
		wine.setDescription(source.getDescription());
		wine.setYear(source.getYear());
		wine.setBottlePrice(source.getBottlePrice());
		wine.setAvailableBottles(source.getAvailableBottles());
		wine.setWineType(wineTypeService.findOneById(source.getWineTypeId()));
		wine.setWinery(wineryService.findOneById(source.getWineryId()));
		
		
		return wine;
	}

}
