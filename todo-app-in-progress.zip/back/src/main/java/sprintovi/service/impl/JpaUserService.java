package sprintovi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sprintovi.model.User;
import sprintovi.repository.UserRepository;
import sprintovi.service.UserService;

import java.util.Optional;

@Service
public class JpaUserService implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public Optional<User> findbyKorisnickoIme(String username) {
        return userRepository.findFirstByUsername(username);
    }

}
