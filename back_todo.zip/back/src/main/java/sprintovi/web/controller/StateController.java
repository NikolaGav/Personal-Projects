package sprintovi.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sprintovi.model.State;
import sprintovi.service.StateService;
import sprintovi.support.StateToStateDto;
import sprintovi.web.dto.StateDto;

@RestController
@RequestMapping(value = "/api/states", produces = MediaType.APPLICATION_JSON_VALUE)
public class StateController {
	
	
	@Autowired
	private StateService stateService;
	
	@Autowired
	private StateToStateDto toStateDto;
	
	@GetMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<StateDto>> getAll() {
		
		List<State> states = stateService.findAll();
		
		return new ResponseEntity<List<StateDto>>(toStateDto.convert(states), HttpStatus.OK);
	}
	

}
