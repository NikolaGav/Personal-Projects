package com.ftninformatika.jwd.modul3.test.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Winery;
import com.ftninformatika.jwd.modul3.test.web.dto.WineryDTO;

@Component
public class WineryToWineryDTO implements Converter<Winery, WineryDTO> {

	@Override
	public WineryDTO convert(Winery source) {
		WineryDTO dto = new WineryDTO();
		
		dto.setId(source.getId());
		dto.setName(source.getName());
		dto.setEstablishmentYear(source.getEstablishmentYear());
		
		return dto;
	}
	
	
	public List<WineryDTO> convert(List<Winery> winery){
		
		List<WineryDTO> wineryDTOs = new ArrayList<>();
		
		for(Winery itWinery : winery) {
			wineryDTOs.add(convert(itWinery));
		}
		
		return wineryDTOs;
	}

}
