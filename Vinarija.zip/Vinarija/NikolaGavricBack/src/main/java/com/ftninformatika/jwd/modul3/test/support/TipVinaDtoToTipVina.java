package com.ftninformatika.jwd.modul3.test.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.TipVina;
import com.ftninformatika.jwd.modul3.test.service.TipVinaService;
import com.ftninformatika.jwd.modul3.test.web.dto.TipVinaDto;

@Component
public class TipVinaDtoToTipVina implements Converter<TipVinaDto, TipVina> {
	
	@Autowired
	private TipVinaService vinaService;

	@Override
	public TipVina convert(TipVinaDto source) {
		
		TipVina tipVina;
		
		if(source.getId() == null) {
			tipVina = new TipVina();
		} else {
			tipVina = vinaService.findOne(source.getId());
		}
		
		tipVina.setIme(source.getIme());
		
		
		return tipVina;
	}

}
