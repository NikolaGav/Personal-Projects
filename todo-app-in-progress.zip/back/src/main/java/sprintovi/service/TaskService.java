package sprintovi.service;

import java.util.Optional;

import sprintovi.model.Task;

public interface TaskService {
	
	Optional<Task> findOne(Long id);
	
	Task save (Task task);
	
	Task delete(Long id);
	
	

}
