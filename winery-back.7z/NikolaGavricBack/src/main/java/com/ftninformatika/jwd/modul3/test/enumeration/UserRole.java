package com.ftninformatika.jwd.modul3.test.enumeration;

public enum UserRole {
    ADMIN,
    USER
}
