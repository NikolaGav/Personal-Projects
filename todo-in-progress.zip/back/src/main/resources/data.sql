INSERT INTO `user` (id, username, password, role)
              VALUES (1,'miroslav','$2y$12$NH2KM2BJaBl.ik90Z1YqAOjoPgSd0ns/bF.7WedMxZ54OhWQNNnh6','ADMIN');
INSERT INTO `user` (id, username, password, role)
              VALUES (2,'tamara','$2y$12$DRhCpltZygkA7EZ2WeWIbewWBjLE0KYiUO.tHDUaJNMpsHxXEw9Ky','KORISNIK');
INSERT INTO `user` (id, username, password, role)
              VALUES (3,'petar','$2y$12$i6/mU4w0HhG8RQRXHjNCa.tG2OwGSVXb0GYUnf8MZUdeadE4voHbC','KORISNIK');
              
              
INSERT INTO sprint (name, points)
VALUES ('Test Sprint', 15);
INSERT INTO sprint (name, points)
VALUES ('Production Sprint', 11);


INSERT INTO state (name)
VALUES ('NEW');
INSERT INTO state (name)
VALUES ('IN PROGRESS');
INSERT INTO state (name)
VALUES ('FINISHED');


INSERT INTO task (employee, name, points, sprint_id, state_id)
VALUES ('Marko', 'Kreiraj Login', 7, 1, 2);
INSERT INTO task (employee, name, points, sprint_id, state_id)
VALUES ('Ivan', 'Autorizacija na back-u', 7, 1, 3);
INSERT INTO task (employee, name, points, sprint_id, state_id)
VALUES ('Marko', 'Testiraj login', 1, 1, 1);
INSERT INTO task (employee, name, points, sprint_id, state_id)
VALUES ('Ivan', 'Pokreni bazu', 7, 2, 3);
INSERT INTO task (employee, name, points, sprint_id, state_id)
VALUES ('Jovan', 'Napisi Unit Testove', 4, 2, 1);


