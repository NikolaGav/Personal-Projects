package sprintovi.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.State;
import sprintovi.web.dto.StateDto;

@Component
public class StateToStateDto implements Converter<State, StateDto> {
	

	@Override
	public StateDto convert(State source) {
		
		StateDto dto = new StateDto();
		
		dto.setId(source.getId());
		dto.setName(source.getName());
		
		return dto;
	}
	
	public List<StateDto> convert(List<State> state) {
		
		List<StateDto> stateDto = new ArrayList<StateDto>();
		
		for(State itState : state) {
			stateDto.add(convert(itState));
		}
		
		return stateDto;
		
	}
	
	
	

}
