package com.ftninformatika.jwd.modul3.test.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.Vinarija;

@Service
public interface VinarijaService {
	
	
	List<Vinarija> getAll();
	
	Vinarija findOne(Long id);
	
	
	

}
