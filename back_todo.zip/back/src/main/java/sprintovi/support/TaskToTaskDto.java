package sprintovi.support;


import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Task;
import sprintovi.service.SprintService;
import sprintovi.service.StateService;
import sprintovi.service.TaskService;
import sprintovi.web.dto.TaskDto;

@Component
public class TaskToTaskDto implements Converter<Task, TaskDto > {
	

	@Override
	public TaskDto convert(Task source) {
		
		TaskDto dto = new TaskDto();
		
		dto.setId(source.getId());
		dto.setName(source.getName());
		dto.setPoints(source.getPoints());
		dto.setEmployee(source.getEmployee());
		
		dto.setSprintId(source.getSprint().getId());
		dto.setStateName(source.getSprint().getName());
		
		dto.setStateId(source.getState().getId());
		dto.setStateName(source.getState().getName());

		return dto;
	}
	
	
	public List<TaskDto> convert(List<Task> source) {
		
		List<TaskDto> list = new ArrayList<TaskDto>();
		
		for(Task iTask : source) {
			list.add(convert(iTask));
		}
		
		return list;
	}
	
	

}
