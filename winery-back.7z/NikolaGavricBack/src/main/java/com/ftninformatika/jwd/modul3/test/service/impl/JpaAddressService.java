package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.Address;
import com.ftninformatika.jwd.modul3.test.repository.AddressRepository;

@Service
public class JpaAddressService implements AddressService {
	
	@Autowired
	private AddressRepository repository;

	@Override
	public Optional<Address> findOne(Long id) {
		return repository.findById(id);
	}

	@Override
	public List<Address> findAll() {
		return repository.findAll();
	}

	@Override
	public Address save(Address address) {
		return repository.save(address);
	}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
		
	}

}
