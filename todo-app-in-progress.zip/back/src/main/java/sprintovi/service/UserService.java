package sprintovi.service;

import sprintovi.model.User;

import java.util.Optional;

public interface UserService {

    Optional<User> findbyKorisnickoIme(String username);
}
