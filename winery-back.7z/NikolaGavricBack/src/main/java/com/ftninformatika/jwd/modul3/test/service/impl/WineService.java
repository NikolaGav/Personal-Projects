package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.List;

import org.springframework.data.domain.Page;

import com.ftninformatika.jwd.modul3.test.model.Wine;

public interface WineService {
	
	
	
	Wine findOneById(Long id);
	
	Wine save(Wine entity);
	
	Wine update(Wine entity);
	
	Wine delete(Long id);
	
	Page<Wine> findSearch(Long wineryId, String wineName, Integer pageNo);
	
	List<Wine> findAll();
	

}
