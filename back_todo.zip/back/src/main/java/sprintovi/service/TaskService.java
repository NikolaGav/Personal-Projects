package sprintovi.service;

import java.util.Optional;

import org.springframework.data.domain.Page;

import sprintovi.model.Task;

public interface TaskService {
	
	Task findOneById(Long id);
	
	Task save (Task task);
	
	Task delete(Long id);
	
	Page<Task> search(String nameTask, Long sprintId, Integer pageNo);
	
	

}
