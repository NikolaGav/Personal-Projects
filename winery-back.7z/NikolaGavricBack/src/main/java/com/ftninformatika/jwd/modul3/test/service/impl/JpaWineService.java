package com.ftninformatika.jwd.modul3.test.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.Wine;
import com.ftninformatika.jwd.modul3.test.repository.WineRepository;

@Service
public class JpaWineService implements WineService {
	
	@Autowired
	private WineRepository wineRepository;

	@Override
	public Wine findOneById(Long id) {
		return wineRepository.findOneById(id);
	}

	@Override
	public Wine save(Wine entity) {
		return wineRepository.save(entity);
	}

	@Override
	public Wine update(Wine entity) {
		return wineRepository.save(entity);
	}

	@Override
	public Wine delete(Long id) {

		Wine wine = wineRepository.findOneById(id);
		wineRepository.deleteById(id);
		
		return null;
	}


	
	@Override
	public Page<Wine> findSearch(Long wineryId, String name, Integer pageNo) {
		if (name == null) {
			name = "";
		}
		
		if (wineryId == null) {
			return wineRepository.findByNameIgnoreCaseContains(name, PageRequest.of(pageNo, 2));
		}
		
		return wineRepository.findByWineryIdAndNameIgnoreCaseContains(wineryId, name, PageRequest.of(pageNo, 2));
	}


	@Override
	public List<Wine> findAll() {
		return wineRepository.findAll();
	}



	

}
