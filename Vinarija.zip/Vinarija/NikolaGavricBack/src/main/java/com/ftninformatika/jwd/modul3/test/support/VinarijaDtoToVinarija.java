package com.ftninformatika.jwd.modul3.test.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Vinarija;
import com.ftninformatika.jwd.modul3.test.service.VinarijaService;
import com.ftninformatika.jwd.modul3.test.web.dto.VinarijaDto;

@Component
public class VinarijaDtoToVinarija implements Converter<VinarijaDto, Vinarija> {
	
	@Autowired
	private VinarijaService vinarijaService;

	@Override
	public Vinarija convert(VinarijaDto source) {
		
		Vinarija vinarija;
		
		if(source.getId() == null) {
			vinarija = new Vinarija();
		} else {
			vinarija = vinarijaService.findOne(source.getId());
		}
		
		vinarija.setIme(source.getIme());
		vinarija.setGodinaOsnivanja(source.getGodinaOsnivanja());
		
		
		return vinarija;
	}

	

}
