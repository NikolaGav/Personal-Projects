package sprintovi.service.impl;

import java.util.Optional;

import org.springframework.stereotype.Service;

import sprintovi.model.Task;
import sprintovi.service.TaskService;

@Service
public class JpaTaskService implements TaskService {

	@Override
	public Optional<Task> findOne(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task save(Task task) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task delete(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
