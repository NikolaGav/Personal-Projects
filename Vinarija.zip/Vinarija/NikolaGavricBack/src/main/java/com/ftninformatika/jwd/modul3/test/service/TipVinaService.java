package com.ftninformatika.jwd.modul3.test.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ftninformatika.jwd.modul3.test.model.TipVina;

@Service
public interface TipVinaService {
	
	
	List<TipVina> getAll();
	
	TipVina findOne(Long id);
	
	

}
