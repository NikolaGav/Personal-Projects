package sprintovi.service;

import java.util.List;
import java.util.Optional;

import sprintovi.model.Sprint;
import sprintovi.model.State;

public interface StateService {
	
	List<State> findAll();
	
	State findOneById(Long id);
	
	State save (State state);
	

}
