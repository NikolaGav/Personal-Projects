package sprintovi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import sprintovi.model.Task;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
	
	Task findOneById(Long id);
	
	Page<Task> findByNameIgnoreCaseContains(String name, Pageable pageable);
	
	Page<Task> findBySprintIdAndNameIgnoreCaseContains(Long sprintId, String name, Pageable pageable);
	
	

}
