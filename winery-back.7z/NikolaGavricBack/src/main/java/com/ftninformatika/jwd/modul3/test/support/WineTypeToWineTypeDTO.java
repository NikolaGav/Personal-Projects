package com.ftninformatika.jwd.modul3.test.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.WineType;
import com.ftninformatika.jwd.modul3.test.web.dto.WineTypeDTO;

@Component
public class WineTypeToWineTypeDTO implements Converter<WineType, WineTypeDTO> {

	@Override
	public WineTypeDTO convert(WineType source) {
		
		WineTypeDTO dto = new WineTypeDTO();
		
		dto.setId(source.getId());
		dto.setName(source.getName());
		
		
		return dto;
	}
	
	
	public List<WineTypeDTO> convert (List<WineType> wines) {
		
		List<WineTypeDTO> wineTypeDTOs = new ArrayList<>();
		for(WineType itType : wines) {
			wineTypeDTOs.add(convert(itType));
		}
		
		return wineTypeDTOs;
	}
	

}
