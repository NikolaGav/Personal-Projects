package com.ftninformatika.jwd.modul3.test.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.User;
import com.ftninformatika.jwd.modul3.test.service.impl.AddressService;
import com.ftninformatika.jwd.modul3.test.service.impl.UserService;
import com.ftninformatika.jwd.modul3.test.web.dto.UserDTO;

@Component
public class UserDtoToUser implements Converter<UserDTO, User> {

		@Autowired
	    private UserService userService;

	    @Autowired
	    private AddressService addressService;

	    @Override
	    public User convert(UserDTO userDTO) {
	        User user = null;
	        if (userDTO.getId() != null) {
	            user = userService.findOne(userDTO.getId()).get();
	        }

	        if (user == null) {
	            user = new User();
	        }

	        user.setUsername(userDTO.getUsername());
	        user.setAddress(addressService.findOne(userDTO.getAddressDTO().getId()).get());
	        user.seteMail(userDTO.geteMail());
	        user.setFirstName(userDTO.getFirstName());
	        user.setLastName(user.getLastName());

	        return user;
	    }

	}