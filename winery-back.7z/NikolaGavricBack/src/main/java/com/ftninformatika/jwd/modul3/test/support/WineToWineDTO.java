package com.ftninformatika.jwd.modul3.test.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.Wine;
import com.ftninformatika.jwd.modul3.test.web.dto.WineDTO;

@Component
public class WineToWineDTO implements Converter<Wine, WineDTO> {

	@Override
	public WineDTO convert(Wine source) {
		
		WineDTO dto = new WineDTO();
		
		dto.setId(source.getId());
		dto.setName(source.getName());
		dto.setDescription(source.getDescription());
		dto.setYear(source.getYear());
		dto.setBottlePrice(source.getBottlePrice());
		dto.setAvailableBottles(source.getAvailableBottles());
		dto.setWineTypeId(source.getWineType().getId());
		dto.setWineTypeName(source.getWineType().getName());
		dto.setWineryId(source.getWinery().getId());
		dto.setWineryName(source.getWinery().getName());
		
		return dto;
	}
	
	
	
	public List<WineDTO> convert(List<Wine> wine){
		
		List<WineDTO> wineDTOs = new ArrayList<>();
		
		for(Wine itWine : wine) {
			wineDTOs.add(convert(itWine));
		}
		
		return wineDTOs;
	}
	

}
