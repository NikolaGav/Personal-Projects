package sprintovi.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sprintovi.model.Sprint;
import sprintovi.model.State;
import sprintovi.repository.StateRepository;
import sprintovi.service.StateService;

@Service
public class JpaStateService implements StateService {

	@Autowired
	private StateRepository stateRepository;

	@Override
	public List<State> findAll() {
		return stateRepository.findAll();
	}

	@Override
	public State save(State state) {
		return stateRepository.save(state);
	}

	@Override
	public State findOneById(Long id) {
		return stateRepository.findOneById(id);
	}




}
