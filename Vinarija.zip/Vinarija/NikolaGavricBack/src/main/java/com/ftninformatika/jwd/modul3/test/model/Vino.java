package com.ftninformatika.jwd.modul3.test.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Vino {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String ime;
	
	@Column
	private String opis;
	
	@Column(nullable = false)
	private Integer godinaProizvodnje;
	
	@Column
	private Double cenaFlase;
	
	@Column
	private Integer brojDosupnihFlasa;
	
	@ManyToOne
	private TipVina tipVina;
	
	@ManyToOne
	private Vinarija vinarija;

	public Vino() {
		super();
	}

	public Vino(Long id, String ime, String opis, Integer godinaProizvodnje, Double cenaFlase,
			Integer brojDosupnihFlasa, TipVina tipVina, Vinarija vinarija) {
		super();
		this.id = id;
		this.ime = ime;
		this.opis = opis;
		this.godinaProizvodnje = godinaProizvodnje;
		this.cenaFlase = cenaFlase;
		this.brojDosupnihFlasa = brojDosupnihFlasa;
		this.tipVina = tipVina;
		this.vinarija = vinarija;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public Integer getGodinaProizvodnje() {
		return godinaProizvodnje;
	}

	public void setGodinaProizvodnje(Integer godinaProizvodnje) {
		this.godinaProizvodnje = godinaProizvodnje;
	}

	public Double getCenaFlase() {
		return cenaFlase;
	}

	public void setCenaFlase(Double cenaFlase) {
		this.cenaFlase = cenaFlase;
	}

	public Integer getBrojDosupnihFlasa() {
		return brojDosupnihFlasa;
	}

	public void setBrojDosupnihFlasa(Integer brojDosupnihFlasa) {
		this.brojDosupnihFlasa = brojDosupnihFlasa;
	}

	public TipVina getTipVina() {
		return tipVina;
	}

	public void setTipVina(TipVina tipVina) {
		this.tipVina = tipVina;
	}

	public Vinarija getVinarija() {
		return vinarija;
	}

	public void setVinarija(Vinarija vinarija) {
		this.vinarija = vinarija;
	}
	
	
	
	
	

}
