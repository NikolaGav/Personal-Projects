package sprintovi.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Sprint;
import sprintovi.web.dto.SprintDto;

@Component
public class SprintToSprintDTO implements Converter<Sprint, SprintDto> {
	
	

	@Override
	public SprintDto convert(Sprint source) {
		
		SprintDto dto = new SprintDto();
		dto.setId(source.getId());
		dto.setName(source.getName());
		dto.setPoints(Integer.parseInt(source.getPoints()));

		return dto;
	}
	
	
	public List<SprintDto> convert(List<Sprint> source) {
		List<SprintDto> taskDto = new ArrayList<SprintDto>();
		
		for(Sprint itSprint : source) {
			taskDto.add(convert(itSprint));
		}
		
		return taskDto;
		
	}
	
	

}
