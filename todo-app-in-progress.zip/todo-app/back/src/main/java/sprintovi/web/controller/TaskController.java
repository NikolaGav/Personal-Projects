package sprintovi.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import sprintovi.model.Task;
import sprintovi.service.TaskService;
import sprintovi.support.TaskDtoToTask;
import sprintovi.support.TaskToTaskDto;
import sprintovi.web.dto.TaskDto;

@RestController
@RequestMapping(value = "/api/tasks", produces = MediaType.APPLICATION_JSON_VALUE)
public class TaskController {
	
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private TaskToTaskDto toTaskDto;
	
	@Autowired
	private TaskDtoToTask toTask;
	
	
	@GetMapping
	public ResponseEntity<List<TaskDto>> getAll(
			@RequestParam(required = false) Long sprintId,
			@RequestParam(required = false) String taskName,
			@RequestParam(value = "pageNo", defaultValue = "0") Integer pageNo
			) {
		
		Page<Task> page = taskService.search(taskName, sprintId, pageNo);
		
		HttpHeaders headers = new HttpHeaders();
		
		headers.add("total-pages", Integer.toString(page.getTotalPages()));

		return new ResponseEntity<List<TaskDto>>(toTaskDto.convert(page.getContent()), headers, HttpStatus.OK);
		
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<TaskDto> getOne(@PathVariable Long id) {
		
		Task task = taskService.findOneById(id);
		
		if(task != null) {
			return new ResponseEntity<TaskDto>(toTaskDto.convert(task), HttpStatus.OK);
		} else {
			return new ResponseEntity<TaskDto>(HttpStatus.NOT_FOUND);
		}
		
	}
	
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TaskDto> create(@Valid @RequestBody TaskDto taskDto) {
		
		Task task = toTask.convert(taskDto);
		Task saveTask = taskService.save(task);
		
		return new ResponseEntity<TaskDto>(toTaskDto.convert(saveTask), HttpStatus.CREATED);
		
	}
	
	
	@PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<TaskDto> update(@PathVariable Long id, @Valid @RequestBody TaskDto taskDto) {
		
		if(!id.equals(taskDto.getId())) {
			return new ResponseEntity<TaskDto>(HttpStatus.BAD_REQUEST);
		}
		
		Task task = toTask.convert(taskDto);
		Task saveTask = taskService.save(task);
		
		return new ResponseEntity<TaskDto>(toTaskDto.convert(saveTask), HttpStatus.OK);
		
	}
	
	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<TaskDto> delete(@PathVariable Long id) {
		
		Task deleted = taskService.delete(id);
		
		if(deleted == null) {
			return new ResponseEntity<TaskDto>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<TaskDto>(toTaskDto.convert(deleted), HttpStatus.OK);
		
	}
	

}
