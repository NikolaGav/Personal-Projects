package sprintovi.service.impl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import sprintovi.model.Task;
import sprintovi.repository.TaskRepository;
import sprintovi.service.TaskService;

@Service
public class JpaTaskService implements TaskService {



	@Autowired
	private TaskRepository taskRepository;



	@Override
	public Task save(Task task) {
		return taskRepository.save(task);
	}

	@Override
	public Task delete(Long id) {

		Task task = taskRepository.findOneById(id);
		taskRepository.deleteById(id);
		
		return null;
		
	}

	@Override
	public Page<Task> search(String nameTask, Long sprintId, Integer pageNo) {
		
		if(nameTask == null) {
			nameTask = "";
		}
		
		if(sprintId == null) {
			return taskRepository.findByNameIgnoreCaseContains(nameTask, PageRequest.of(pageNo, 3));
		}
		
		return taskRepository.findBySprintIdAndNameIgnoreCaseContains(sprintId, nameTask, PageRequest.of(pageNo, 3));
		
	}

	@Override
	public Task findOneById(Long id) {
		return taskRepository.findOneById(id);
	}

}
