package com.ftninformatika.jwd.modul3.test.web.dto;

import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.Length;

public class WineDTO {
	
	
	
	private Long id;
	
	
	private String name;
	
	@Length(max = 120)
	private String description;
	
	@Min(value = 0)
	private Integer year;
	
	@Min(value = 0)
	private Double bottlePrice;
	
	
	private Integer availableBottles;
	
	
	private Long wineTypeId;
	private String wineTypeName;
	
	
	private Long wineryId;
	
	private String wineryName;

	public WineDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Double getBottlePrice() {
		return bottlePrice;
	}

	public void setBottlePrice(Double bottlePrice) {
		this.bottlePrice = bottlePrice;
	}

	public Integer getAvailableBottles() {
		return availableBottles;
	}

	public void setAvailableBottles(Integer availableBottles) {
		this.availableBottles = availableBottles;
	}

	public Long getWineTypeId() {
		return wineTypeId;
	}

	public void setWineTypeId(Long wineTypeId) {
		this.wineTypeId = wineTypeId;
	}

	public String getWineTypeName() {
		return wineTypeName;
	}

	public void setWineTypeName(String wineTypeName) {
		this.wineTypeName = wineTypeName;
	}

	public Long getWineryId() {
		return wineryId;
	}

	public void setWineryId(Long wineryId) {
		this.wineryId = wineryId;
	}

	public String getWineryName() {
		return wineryName;
	}

	public void setWineryName(String wineryName) {
		this.wineryName = wineryName;
	}
	
	
	
	
	

}
