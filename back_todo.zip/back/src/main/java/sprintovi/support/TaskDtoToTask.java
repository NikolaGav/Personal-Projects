package sprintovi.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Task;
import sprintovi.service.SprintService;
import sprintovi.service.StateService;
import sprintovi.service.TaskService;
import sprintovi.web.dto.TaskDto;

@Component
public class TaskDtoToTask implements Converter<TaskDto, Task> {
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private SprintService sprintService;
	
	@Autowired
	private StateService stateService;
	

	@Override
	public Task convert(TaskDto source) {
		
		Task task;
		
		if(source.getId() == null) {
			task = new Task();
		} else {
			task = taskService.findOneById(source.getId());
		}
		
		task.setName(source.getName());
		task.setPoints(source.getPoints());
		task.setEmployee(source.getEmployee());
		task.setSprint(sprintService.findOneById(source.getSprintId()));
		task.setState(stateService.findOneById(source.getStateId()));
		
		
		return task;
	}

}
