package com.ftninformatika.jwd.modul3.test.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import com.ftninformatika.jwd.modul3.test.model.TipVina;
import com.ftninformatika.jwd.modul3.test.web.dto.TipVinaDto;

@Component
public class TipVinaToTipVinaDto implements Converter<TipVina, TipVinaDto> {
	
	

	@Override
	public TipVinaDto convert(TipVina tipVina) {
		
		TipVinaDto dto = new TipVinaDto();
		
		dto.setId(tipVina.getId());
		dto.setIme(tipVina.getIme());
		
		
		return dto;
	}
	
	
	public List<TipVinaDto> convert(List<TipVina> tipVina){
		
		List<TipVinaDto> lista = new ArrayList<TipVinaDto>();
		
		for(TipVina iTipVina : tipVina) {
			lista.add(convert(iTipVina));
		}
		
		return lista;
	}
	

}
